﻿CKEDITOR.plugins.setLang('lineheight','en', {
    title: 'Line Height'
} );
