﻿(function () {
    var currentTop = '1em';
    var currentBottom = '1em';
	function addCombo( editor, comboName, styleType, lang, entries, defaultLabel, styleDefinition, order ) {
	    var config = editor.config, style = new CKEDITOR.style(styleDefinition);
	    var currentValue = '1.6em';
		var names = entries.split( ';' ),values = [];
		var styles = {};
		for ( var i = 0; i < names.length; i++ ) {
			var parts = names[ i ];
			if ( parts ) {
				parts = parts.split( '/' );
				var vars = {},name = names[ i ] = parts[ 0 ];
				vars[ styleType ] = values[ i ] = parts[ 1 ] || name;
				styles[ name ] = new CKEDITOR.style( styleDefinition, vars );
				styles[ name ]._.definition.name = name;
			} else
				names.splice( i--, 1 );
		}
		editor.addCommand('customDialog', new CKEDITOR.dialogCommand('customDialog'));
		editor.ui.addButton('CustomSpacing',
            {
                label: 'Custom spacing',
                command: 'customDialog',
                toolbar: 'lineheight',
                icon: 'plugins/lineheight/icons/lineheight.png'
            });

		CKEDITOR.dialog.add('customDialog', function (editor) {
		    return {
		        title: 'Line spacing',
		        minWidth: 100,
		        minHeight: 100,
		        contents:
                [
                    {
                        id: 'general',
                        label: 'Settings',
                        elements:
                        [
                            {
                                type: 'select',
                                id: 'spacebefore',
                                label: 'Space before',
                                controlStyle: 'width: 7em',
                                items:
                                [
                                    ['None', '1em'],
                                    ['1.5 em', '1.5em'],
                                    ['2 em', '2em'],
                                    ['2.5 em', '2.5em'],
                                    ['3 em', '3em']
                                ],
                                'default': currentTop,
                                commit: function (data) {
                                    data.spaceBefore = this.getValue();
                                }
                            },
                            {
                                type: 'select',
                                id: 'spaceafter',
                                label: 'Space after',
                                controlStyle: 'width: 7em;',
                                items:
                                [
                                    ['None', '1em'],
                                    ['1.5 em', '1.5em'],
                                    ['2 em', '2em'],
                                    ['2.5 em', '2.5em'],
                                    ['3 em', '3em']
                                ],
                                'default': currentBottom,
                                commit: function (data) {
                                    data.spaceAfter = this.getValue();
                                }
                            },
                            {
                                type: 'select',
                                id: 'interval',
                                label: 'Line spacing',
                                items:
                                [
                                    ['Standard', '1.6em'],
                                    ['1.5 line', '2.4em'],
                                    ['Double', '3.2em'],
                                    ['Minimum', '1em']
                                ],
                                'default': '1.6em',
                                commit: function (data) {
                                    data.interval = this.getValue();
                                }
                            },
                            {
                                type: 'text',
                                id: 'spaceValue',
                                label: 'Multiply',
                                controlStyle: 'width: 7em;',
                                commit: function (data) {
                                    data.spaceValue = this.getValue();
                                    if (data.spaceValue !== '') {
                                        data.interval = (Number(data.interval.replace('em', '')) * Number(data.spaceValue)) + 'em';
                                    }
                                }
                            }
                        ]
                    }
                ],
		        onOk: function () {
		            var data = {};
		            this.commitContent(data);
		            editor.focus();
		            editor.fire('saveSnapshot');
		            var pSpace = new CKEDITOR.style({ element: 'p', attributes: { 'style': 'margin-top:' + data.spaceBefore + ';margin-bottom:' + data.spaceAfter + ';line-height:' + data.interval } });
		            editor.applyStyle(pSpace);
		            currentTop = data.spaceBefore;
		            currentBottom = data.spaceAfter;
		        }
		    };
		});
		editor.ui.addRichCombo( comboName, {
		    label: editor.lang.lineheight.title,
		    title: editor.lang.lineheight.title,
			toolbar: 'styles,' + order,
			allowedContent: style,
			requiredContent: style,
			panel: {
				css: [ CKEDITOR.skin.getPath( 'editor' ) ].concat( config.contentsCss ),
				multiSelect: false,
				attributes: { 'aria-label': editor.lang.lineheight.title }
			},
			init: function() {
				this.startGroup(editor.lang.lineheight.title);
				for ( var i = 0; i < names.length; i++ ) {
					var name = names[ i ];
					this.add( name, name );
				}
			},
			onClick: function( value ) {
				editor.focus();
				editor.fire( 'saveSnapshot' );
				var style = styles[ value ];
				editor[ this.getValue() == value ? 'removeStyle' : 'applyStyle' ]( style );
				editor.fire( 'saveSnapshot' );
			},
			onRender: function() {
				editor.on( 'selectionChange', function( ev ) {
					currentValue = this.getValue();
					var elementPath = ev.data.path,elements = elementPath.elements;
					for ( var i = 0, element; i < elements.length; i++ ) {
					    element = elements[i];
						for ( var value in styles ) {
							if ( styles[ value ].checkElementMatch( element, true, editor ) ) {
								if ( value !== currentValue )
									this.setValue( value );
								return;
							}
						}
					}
					this.setValue( '', defaultLabel );
				}, this );
			},
			refresh: function() {
				if ( !editor.activeFilter.check( style ) )
					this.setState( CKEDITOR.TRISTATE_DISABLED );
			}
		});
	}
	
    CKEDITOR.plugins.add('lineheight', {
		requires: 'richcombo',
		lang: 'en',
		init: function( editor ) {
			var config = editor.config;
			addCombo( editor, 'lineheight', 'size', editor.lang.lineheight.title, config.line_height, editor.lang.lineheight.title, config.lineHeight_style, 40 );
		}
	} );
})();

CKEDITOR.config.line_height = '1em;1.2em;1.4em;1.6em;1.8em;2em;2.2em;2.4em;2.6em;2.8em;3em;3.2em;';
CKEDITOR.config.lineHeight_style = {
	element: 'p',
	styles: { 'line-height': '#(size) !important' },
	overrides: [ {
	    element: 'line-height', attributes: { 'size': null }
	} ]
};


