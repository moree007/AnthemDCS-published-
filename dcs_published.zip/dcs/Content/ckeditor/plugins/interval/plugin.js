﻿CKEDITOR.plugins.add('interval',
{
    init: function (editor) {
        

        editor.addCommand('customDialog', new CKEDITOR.dialogCommand('customDialog'));
        editor.ui.addButton('CustomSpacing',
            {
                label: 'Custom spacing',
                command: 'customDialog',
                toolbar: 'lineheight',
                icon: 'plugins/lineheight/icons/lineheight.png'
            });

        CKEDITOR.dialog.add('customDialog', function (editor) {
            return {
                title: 'Line spacing',
                minWidth: 100,
                minHeight: 100,
                contents:
                [
                    {
                        id: 'general',
                        label: 'Settings',
                        elements:
                        [
                            {
                                type: 'select',
                                id: 'spacebefore',
                                label: 'Space before',
                                controlStyle: 'width: 7em',
                                items:
                                [
                                    ['None', '1em'],
                                    ['1.5 em', '1.5em'],
                                    ['2 em', '2em'],
                                    ['2.5 em', '2.5em'],
                                    ['3 em', '3em']
                                ],
                                'default': currentTop,
                                commit: function (data) {
                                    data.spaceBefore = this.getValue();
                                }
                            },
                            {
                                type: 'select',
                                id: 'spaceafter',
                                label: 'Space after',
                                controlStyle: 'width: 7em;',
                                items:
                                [
                                    ['None', '1em'],
                                    ['1.5 em', '1.5em'],
                                    ['2 em', '2em'],
                                    ['2.5 em', '2.5em'],
                                    ['3 em', '3em']
                                ],
                                'default': currentBottom,
                                commit: function (data) {
                                    data.spaceAfter = this.getValue();
                                }
                            },
                            {
                                type: 'select',
                                id: 'interval',
                                label: 'Line spacing',
                                items:
                                [
                                    ['Standard', '1.6em'],
                                    ['1.5 line', '2.4em'],
                                    ['Double', '3.2em'],
                                    ['Minimum', '1em']
                                ],
                                'default': '1.6em',
                                commit: function (data) {
                                    data.interval = this.getValue();
                                }
                            },
                            {
                                type: 'text',
                                id: 'spaceValue',
                                label: 'Multiply',
                                controlStyle: 'width: 7em;',
                                commit: function (data) {
                                    data.spaceValue = this.getValue();
                                    if (data.spaceValue !== '') {
                                        data.interval = (Number(data.interval.replace('em', '')) * Number(data.spaceValue)) + 'em';
                                    }
                                }
                            }
                        ]
                    }
                ],
                onOk: function () {
                    var data = {};
                    this.commitContent(data);
                    editor.focus();
                    editor.fire('saveSnapshot');
                    var pSpace = new CKEDITOR.style({ element: 'p', attributes: { 'style': 'margin-top:' + data.spaceBefore + ';margin-bottom:' + data.spaceAfter + ';line-height:' + data.interval } });
                    editor.applyStyle(pSpace);
                    currentTop = data.spaceBefore;
                    currentBottom = data.spaceAfter;
                }
            };
        });
    }
});